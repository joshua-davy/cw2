package edu.leicester.co2103.part1s2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Part1s2ApplicationTests {

    @Test
    void contextLoads() {
    }

}
