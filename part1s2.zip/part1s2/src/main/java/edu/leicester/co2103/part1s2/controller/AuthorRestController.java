package edu.leicester.co2103.part1s2.controller;
import edu.leicester.co2103.part1s2.ErrorInfo;
import edu.leicester.co2103.part1s2.domain.Author;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.util.UriComponentsBuilder;
import edu.leicester.co2103.part1s2.repo.authorRepository;
import java.util.Optional;

@RestController
@RequestMapping("/api")
public class AuthorRestController {

    @Autowired
    private authorRepository authorRepository;

    /*
     * Retrieve all authors
     */
    @GetMapping("/authors")
    public ResponseEntity<List<Author>> listAllAuthors() {
        List<Author> authors = authorRepository.findAll();
        if (authors.isEmpty()) {
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);  // Return HTTP 204 No Content.
        }
        return new ResponseEntity<>(authors, HttpStatus.OK);
    }

    /*
     * Retrieve single author by ID
     */
    @GetMapping("/authors/{id}")
    public ResponseEntity<?> getAuthor(@PathVariable("id") Long id) {
        Optional<Author> author = authorRepository.findById(id);
        if (!author.isPresent()) {
            return new ResponseEntity<>(new ErrorInfo("Author with id " + id + " not found"), HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<>(author.get(), HttpStatus.OK);
    }

    /*
     * Create a new author
     */
    @PostMapping("/authors")
    public ResponseEntity<?> createAuthor(@RequestBody Author author, UriComponentsBuilder ucBuilder) {
        if (authorRepository.existsById(author.getId())) {
            return new ResponseEntity<>(new ErrorInfo("An author with ID " + author.getId() + " already exists."), HttpStatus.CONFLICT);
        }
        authorRepository.save(author);

        HttpHeaders headers = new HttpHeaders();
        headers.setLocation(ucBuilder.path("/api/authors/{id}").buildAndExpand(author.getId()).toUri());
        return new ResponseEntity<>(headers, HttpStatus.CREATED);
    }

    /*
     * Update an existing author
     */
    @PutMapping("/authors/{id}")
    public ResponseEntity<?> updateAuthor(@PathVariable("id") Long id, @RequestBody Author authorDetails) {
        Optional<Author> currentAuthor = authorRepository.findById(id);

        if (!currentAuthor.isPresent()) {
            return new ResponseEntity<>(new ErrorInfo("Author with id " + id + " not found."), HttpStatus.NOT_FOUND);
        }

        Author author = currentAuthor.get();
        author.setName(authorDetails.getName());
        author.setBirthyear(authorDetails.getBirthyear());
        author.setNationality(authorDetails.getNationality());

        authorRepository.save(author);
        return new ResponseEntity<>(author, HttpStatus.OK);
    }

    /*
     * Delete an author by ID
     */
    @DeleteMapping("/authors/{id}")
    public ResponseEntity<?> deleteAuthor(@PathVariable("id") Long id) {
        Optional<Author> author = authorRepository.findById(id);
        if (!author.isPresent()) {
            return new ResponseEntity<>(new ErrorInfo("Author with id " + id + " not found."), HttpStatus.NOT_FOUND);
        }

        authorRepository.delete(author.get());
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }

    /*
     * Delete all authors
     */
    @DeleteMapping("/authors")
    public ResponseEntity<?> deleteAllAuthors() {
        authorRepository.deleteAll();
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}