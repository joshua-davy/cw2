# CW2-Group-73

## Getting started

I have created all the relevant issue boards. Inside them are the task details and also you can refer to the CW2 pdf in the main directory.

Please create your own branch. Just call it your username and then we can commit and change files without any headaches.

## Add your files

```
git clone <https://campus.cs.le.ac.uk/gitlab/jd534/cw2-group-73.git>#

```

## Collaborate with your team

- [ ] [Invite team members and collaborators](https://docs.gitlab.com/ee/user/project/members/)
- [ ] [Create a new merge request](https://docs.gitlab.com/ee/user/project/merge_requests/creating_merge_requests.html)
- [ ] [Automatically close issues from merge requests](https://docs.gitlab.com/ee/user/project/issues/managing_issues.html#closing-issues-automatically)
- [ ] [Enable merge request approvals](https://docs.gitlab.com/ee/user/project/merge_requests/approvals/)
- [ ] [Set auto-merge](https://docs.gitlab.com/ee/user/project/merge_requests/merge_when_pipeline_succeeds.html)

***

