package edu.leicester.co2103.part1s2.repo;

import edu.leicester.co2103.part1s2.domain.Author;
import org.springframework.data.jpa.repository.JpaRepository;

public interface authorRepository extends JpaRepository<Author,Long> {
}
