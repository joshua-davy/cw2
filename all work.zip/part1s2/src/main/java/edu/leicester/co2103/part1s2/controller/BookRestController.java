package edu.leicester.co2103.part1s2.controller;
import edu.leicester.co2103.part1s2.domain.Book;
import edu.leicester.co2103.part1s2.repo.bookRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.util.UriComponentsBuilder;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/books")
public class BookRestController {

    @Autowired
    private bookRepository bookRepository;

    @GetMapping
    public ResponseEntity<List<Book>> getAllBooks() {
        List<Book> books = bookRepository.findAll();
        if (books.isEmpty()) {
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        }
        return new ResponseEntity<>(books, HttpStatus.OK);
    }

    @GetMapping("/{isbn}")
    public ResponseEntity<Book> getBookByISBN(@PathVariable("isbn") String isbn) {
        Optional<Book> book = bookRepository.findById(isbn);
        return book.map(value -> new ResponseEntity<>(value, HttpStatus.OK))
                .orElseGet(() -> new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    @PostMapping
    public ResponseEntity<Book> createBook(@RequestBody Book book, UriComponentsBuilder ucBuilder) {
        if (bookRepository.existsById(book.getISBN())) {
            return new ResponseEntity<>(HttpStatus.CONFLICT);
        }
        Book savedBook = bookRepository.save(book);
        return ResponseEntity.created(ucBuilder.path("/books/{isbn}").buildAndExpand(book.getISBN()).toUri()).body(savedBook);
    }

    @PutMapping("/{isbn}")
    public ResponseEntity<Book> updateBook(@PathVariable("isbn") String isbn, @RequestBody Book bookDetails) {
        Optional<Book> currentBook = bookRepository.findById(isbn);
        if (!currentBook.isPresent()) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
        currentBook.get().setTitle(bookDetails.getTitle());
        currentBook.get().setPublicationYear(bookDetails.getPublicationYear());
        currentBook.get().setPrice(bookDetails.getPrice());
        currentBook.get().setAuthor(bookDetails.getAuthor());
        bookRepository.save(currentBook.get());
        return new ResponseEntity<>(currentBook.get(), HttpStatus.OK);
    }

    @DeleteMapping("/{isbn}")
    public ResponseEntity<Void> deleteBook(@PathVariable("isbn") String isbn) {
        if (!bookRepository.existsById(isbn)) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
        bookRepository.deleteById(isbn);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}
