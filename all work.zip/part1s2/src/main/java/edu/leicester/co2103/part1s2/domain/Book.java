package edu.leicester.co2103.part1s2.domain;

import jakarta.persistence.*;
import java.util.HashSet;
import java.util.Set;

@Entity
public class Book {
        @Id
        private String ISBN;

        private String title;
        private Integer publicationYear;
        private Double price;

        @ManyToOne(fetch = FetchType.LAZY)
        @JoinColumn(name = "author_id")
        private Author author;

        @ManyToMany(mappedBy = "books")
        private Set<Order> orders = new HashSet<>();

        // Constructors
        public Book() {}

        public Book(String ISBN, String title, Integer publicationYear, Double price) {
                this.ISBN = ISBN;
                this.title = title;
                this.publicationYear = publicationYear;
                this.price = price;
        }

        // Getters and Setters
        public String getISBN() {
                return ISBN;
        }

        public void setISBN(String ISBN) {
                this.ISBN = ISBN;
        }

        public String getTitle() {
                return title;
        }

        public void setTitle(String title) {
                this.title = title;
        }

        public Integer getPublicationYear() {
                return publicationYear;
        }

        public void setPublicationYear(Integer publicationYear) {
                this.publicationYear = publicationYear;
        }

        public Double getPrice() {
                return price;
        }

        public void setPrice(Double price) {
                this.price = price;
        }

        public Author getAuthor() {
                return author;
        }

        public void setAuthor(Author author) {
                this.author = author;
        }

        public Set<Order> getOrders() {
                return orders;
        }

        public void setOrders(Set<Order> orders) {
                this.orders = orders;
        }
}
